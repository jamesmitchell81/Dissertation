//
//  ImageManipulationView.h
//  ImageCropUI
//
//  Created by James Mitchell on 09/04/2016.
//  Copyright © 2016 James Mitchell. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ImageManipulationView : NSImageView
{

}


@end
