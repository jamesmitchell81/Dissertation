//
//  ImageManipulationView.m
//  ImageCropUI
//
//  Created by James Mitchell on 09/04/2016.
//  Copyright © 2016 James Mitchell. All rights reserved.
//

#import "ImageManipulationView.h"

@implementation ImageManipulationView

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    // Drawing code here.
    [[NSColor whiteColor] setFill];
}





@end
